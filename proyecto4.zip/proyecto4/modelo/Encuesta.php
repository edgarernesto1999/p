<?php
require_once 'Conexion.php';

class Encuesta {
    public static function guardar($cedula, $p1, $p2) {
        $conn = Conexion::conectar();
        $stmt = $conn->prepare("INSERT INTO respuestas (cedula, pregunta1, pregunta2) VALUES (?,?,?)");
        $stmt->bind_param("sss", $cedula, $p1, $p2);
        return $stmt->execute();
    }

    public static function obtenerResultados() {
        $conn = Conexion::conectar();
        $sql = "SELECT 
            SUM(CASE WHEN pregunta1 = 'si' THEN 1 ELSE 0 END) AS si_p1,
            SUM(CASE WHEN pregunta1 = 'no' THEN 1 ELSE 0 END) AS no_p1,
            SUM(CASE WHEN pregunta2 = 'si' THEN 1 ELSE 0 END) AS si_p2,
            SUM(CASE WHEN pregunta2 = 'no' THEN 1 ELSE 0 END) AS no_p2
        FROM respuestas";

        return $conn->query($sql)->fetch_assoc();
    }
}
