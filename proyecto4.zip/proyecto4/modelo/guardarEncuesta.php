<?php
session_start();
require_once 'Encuesta.php';
require_once 'Usuario.php';

$cedula = $_SESSION['cedula'];
$p1 = $_POST['pregunta1'] ?? '';
$p2 = $_POST['pregunta2'] ?? '';

if ($p1 && $p2 && !Usuario::yaRespondio($cedula)) {
    Encuesta::guardar($cedula, $p1, $p2);
    echo "Encuesta enviada.<br><a href='../salir.php'>Salir</a>";
} else {
    echo "No se pudo guardar la encuesta o ya fue respondida.<br><a href='../salir.php'>Salir</a>";
}
