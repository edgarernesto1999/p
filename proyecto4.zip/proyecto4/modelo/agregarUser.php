<?php
require_once 'Usuario.php';

Usuario::crear($_POST['cedula'], $_POST['nombre'], $_POST['apellido'], $_POST['pass'], $_POST['rol']);
header("Location: ../index.php");
