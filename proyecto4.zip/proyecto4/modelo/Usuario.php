<?php
require_once 'Conexion.php';

class Usuario {
    public static function autenticar($cedula, $pass) {
        $conn = Conexion::conectar();
        $stmt = $conn->prepare("SELECT * FROM users WHERE cedula = ? AND pass = ?");
        $stmt->bind_param("ss", $cedula, $pass);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public static function yaRespondio($cedula) {
        $conn = Conexion::conectar();
        $stmt = $conn->prepare("SELECT * FROM respuestas WHERE cedula = ?");
        $stmt->bind_param("s", $cedula);
        $stmt->execute();
        return $stmt->get_result()->num_rows > 0;
    }

    public static function crear($cedula, $nombre, $apellido, $pass, $rol) {
        $conn = Conexion::conectar();
        $stmt = $conn->prepare("INSERT INTO users (cedula,nombre,apellido,pass,rol) VALUES (?,?,?,?,?)");
        $stmt->bind_param("sssss", $cedula, $nombre, $apellido, $pass, $rol);
        return $stmt->execute();
    }
}
