<?php
session_start();
require_once 'Usuario.php';

$cedula = $_POST['cedula'] ?? '';
$pass = $_POST['pass'] ?? '';

$user = Usuario::autenticar($cedula, $pass);

if ($user) {
    $_SESSION['cedula'] = $user['cedula'];
    $_SESSION['nombre'] = $user['nombre'];
    $_SESSION['rol'] = $user['rol'];

    if ($user['rol'] == 'admin') {
        header("Location: ../vista/admin.php");
    } elseif ($user['rol'] == 'invitado') {
        if (Usuario::yaRespondio($cedula)) {
            echo "Encuesta ya completada.<br><a href='../salir.php'>Salir</a>";
        } else {
            header("Location: ../vista/invitado.php");
        }
    }
} else {
    echo "Credenciales incorrectas.<br>";
    echo "<a href='../vista/newUser.php'>Crear cuenta</a><br>";
    echo "<a href='../salir.php'>Salir</a>";
}
