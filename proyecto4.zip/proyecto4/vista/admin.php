<?php
session_start();
require_once '../modelo/Encuesta.php';

echo "Bienvenido admin, " . htmlspecialchars($_SESSION['nombre']) . "<br><br>";

$data = Encuesta::obtenerResultados();

echo "Pregunta 1: ¿Sabe POO?<br>SI: {$data['si_p1']}<br>NO: {$data['no_p1']}<br><br>";
echo "Pregunta 2: ¿Sabe PHP?<br>SI: {$data['si_p2']}<br>NO: {$data['no_p2']}<br><br>";
echo "<a href='../salir.php'>Salir</a>";
