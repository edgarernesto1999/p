<?php
session_start();
echo "Bienvenido invitado, " . htmlspecialchars($_SESSION['nombre']);
?>

<form action="../modelo/guardarEncuesta.php" method="post">
    <br><br>¿Sabe POO?<br>
    <select name="pregunta1" required>
        <option value="">-</option>
        <option value="si">Sí</option>
        <option value="no">No</option>
    </select><br><br>

    ¿Sabe PHP?<br>
    <select name="pregunta2" required>
        <option value="">-</option>
        <option value="si">Sí</option>
        <option value="no">No</option>
    </select><br><br>

    <input type="submit" value="Enviar Encuesta">
</form>

<a href="../salir.php">Salir</a>

