<!DOCTYPE html>
<html>
<head><title>Crear Usuario</title></head>
<body>
    <h2>Crear nuevo usuario</h2>
    <form action="../modelo/agregarUser.php" method="post">
        Cédula: <input type="text" name="cedula" required><br>
        Nombre: <input type="text" name="nombre" required><br>
        Apellido: <input type="text" name="apellido" required><br>
        Contraseña: <input type="password" name="pass" required><br>
        Rol:
        <select name="rol" required>
            <option value="">-</option>
            <option value="admin">admin</option>
            <option value="invitado">invitado</option>
        </select><br><br>
        <input type="submit" value="Crear Usuario">
    </form>
    <a href="../salir.php">Salir</a>
</body>
</html>
