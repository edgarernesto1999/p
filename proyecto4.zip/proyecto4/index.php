<?php
session_start();

if (isset($_SESSION['rol'])) {
    if ($_SESSION['rol'] === 'admin') {
        header("Location: vista/admin.php");
        exit;
    } elseif ($_SESSION['rol'] === 'invitado') {
        header("Location: vista/invitado.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
    <h2>Iniciar Sesión</h2>
    <form action="modelo/autenticar.php" method="post">
        Cédula: <input type="text" name="cedula"><br>
        Clave: <input type="password" name="pass"><br>
        <input type="submit" value="Ingresar">
    </form>
    <a href="vista/newUser.php">Crear nueva cuenta</a>
</body>
</html>
