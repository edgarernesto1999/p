<?php
include_once 'conexion.php';

$cedula=$_POST['cedula']??'';
$nombre=$_POST['nombre']??'';
$apellido=$_POST['apellido']??'';

if($cedula&&$nombre&&$apellido){
    $smtm=$conn->prepare("INSERT INTO estudiante (cedula,nombre,apellido) VALUES (?,?,?)");
    $smtm->bind_param("sss",$cedula,$nombre,$apellido);
    $smtm->execute();
}
header("Location: ../vistas/admin.php");
?>