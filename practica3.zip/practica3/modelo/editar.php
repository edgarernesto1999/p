<?php
include_once "conexion.php";

$id = $_POST['id'] ?? null;
$cedula=$_POST['cedula']??'';
$nombre = $_POST['nombre'] ?? '';
$apellido = $_POST['apellido'] ?? '';

if ($id && $cedula && $nombre && $apellido) {
    $stmt = $conn->prepare("UPDATE estudiante SET cedula=? ,nombre=?, apellido=? WHERE id=?");
    $stmt->bind_param("sssi", $cedula,$nombre, $apellido, $id);
    $stmt->execute();
}
header("Location: ../vistas/admin.php");
