<?php 
include_once 'conexion.php';

$id=$_POST['id']??null;
$bus=$conn->prepare("DELETE FROM estudiante WHERE id = ?");
$bus->bind_param("i",$id);
$bus->execute();
header("Location: ../admin.php");
?>