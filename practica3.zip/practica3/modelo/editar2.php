<?php 
include_once 'conexion.php';

$id=$_POST['']??null;
$cedula=$_POST['cedula']??'';
$nombre=$_POST['nombre']??'';
$apellido=$_POST['apellido']??'';

if($id && $cedula && $nombre && $apellido){
    $edit=$conn->prepare("UPDATE estudiante SET cedula = ?, nombre = ?, apellido = ? WHERE id = ?");
    $edit->bind_param("sssi",$cedula,$nombre,$apellido,$id);
    $edit->execute();

}
header("Location: ../admin.php");
?>