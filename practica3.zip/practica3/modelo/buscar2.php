<?php 
include_once 'conexion.php';

$buscar=$_GET['buscar']??'';
$sql="SELECT FROM estudiante WHERE nombre LIKE ?";
$busc=$conn->prepare($sql);
$param="%$buscar%";
$busc->bind_param("s",$buscar);
$busc->execute();
$resultado=$busc->get_result();
header("Location: ../admin.php");

?>