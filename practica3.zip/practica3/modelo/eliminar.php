<?php
require_once "conexion.php";

$id = $_POST['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("DELETE FROM estudiante WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}
header("Location: ../vistas/admin.php");
