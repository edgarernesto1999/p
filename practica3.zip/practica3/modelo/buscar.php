<?php
require_once "conexion.php";

$buscar = $_GET['buscar'] ?? '';
$sql = "SELECT * FROM estudiante WHERE nombre LIKE ?";
$stmt = $conn->prepare($sql);
$param = "%$buscar%";
$stmt->bind_param("s", $param);
$stmt->execute();
$resultado = $stmt->get_result();
