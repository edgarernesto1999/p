<?php
$server="localhost";
$username="root";
$pass="";
$tabla="tabla1";
$conn=mysqli_connect($server,$username,$pass,$tabla);
if($conn){
    echo"estas conectado";
}else{
    echo"no estas conectado";
}
?>