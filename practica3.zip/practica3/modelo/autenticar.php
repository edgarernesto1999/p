<?php
session_start();
include_once 'conexion.php';

$user=$_POST['user_name'];
$pass=$_POST['pass'];

$sql = "SELECT * FROM user WHERE user_name=? AND pass=?";
$smtm= $conn->prepare($sql);
$smtm->bind_param("ss",$user,$pass);
$smtm->execute();
$result=$smtm->get_result();

if($fila=$result->fetch_assoc()){
    $_SESSION['user_name']=$fila['user_name'];
    $_SESSION['rol']=$fila['rol'];

    if($fila['rol']=='admin'){
        header('Location: ../vistas/admin.php');
    }elseif($fila['rol']=='estudiante'){
        header('Location: ../vistas/estudiante.php');
    }else{
        echo "credenciales incorrectas";
    }
}
?>