<?php 
session_start();
include_once '../modelo/conexion.php';

$sql="SELECT id,cedula,nombre,apellido FROM estudiante";

$respuesta=mysqli_query($conn,$sql);
if($respuesta && mysqli_num_rows($respuesta)){
    echo "<h2> lista de estudiantes </h2>";
    echo "<table border=1>";
    echo "<tr> <th>id </th> <th>cedula </th> <th> nombre</th >  <th> apellido</th> </tr>";

    while($row=mysqli_fetch_assoc($respuesta)){
        echo "<tr>";
        echo "<td>" .htmlspecialchars($row['id'])."</td>";
        echo "<td>" .htmlspecialchars($row['cedula'])."</td>";
        echo "<td>" .htmlspecialchars($row['nombre'])."</td>";
        echo "<td>" .htmlspecialchars($row['apellido'])."</td>";

        echo "</tr>";
    }
    echo "</table>";
}else{
echo "sin datos que mostrar";}
echo "<th>  <a href = '../destroy.php' </a> salir </th>";
?>