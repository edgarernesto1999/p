<?php
session_start();


include_once '../modelo/conexion.php';
$sql ="SELECT id,cedula,nombre,apellido FROM estudiante";
$resultado=mysqli_query($conn, $sql);
if($resultado && mysqli_num_rows($resultado)>0){
    echo "<h2> Lista de estudiantes</h2>";
    echo "<table border=1>";
    echo "<tr><th>id</th>  <th>cedula</th> <th>nombre</th> <th>apellido</th> </tr>";
    while($row = mysqli_fetch_assoc($resultado)){
        echo "<tr>";
        echo "<td>".htmlspecialchars($row['id']). "</td>";
        echo "<td>".htmlspecialchars($row['cedula']). "</td>";
        echo "<td>".htmlspecialchars($row['nombre']). "</td>" ;
        echo "<td>".htmlspecialchars($row['apellido']). "</td>" ;

        echo "</tr>";
    }
    echo "</table>";

}

echo "<br> <a href= '../destroy.php'> salir </a>"

?>