<?php

//echo "estas en admin";
//echo "<br> <a href= '../destroy.php'> cerrar session </a>";
session_start();
require_once '../modelo/buscar.php';

?>
<html>
    <head><title>admin</title> </head>
   <h3>Bienvenido <?php echo $_SESSION['user_name']; ?> </h3> 
   <body>
    <form action="../modelo/agregar.php" method="post">
        <input type="text" name="cedula" placeholder="Cédula">
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="text" name="apellido" placeholder="Apellido">
        <input type="submit" value="agregar">


    </form>
    <form method="get" action="admin.php">
        <input type="text" name="buscar" placeholder="buscar por nombre" 
        value="<?php echo htmlspecialchars($_GET['buscar']??'') ;?>">
        <input type="submit" value="buscar">

    </form>
    
    <table border ="1">
        <tr> <th>ID</th> <th>Cédula</th> <th>Nombre</th> <th>Apellido</th> <th> Acciones</th> </tr>
        <?php while ($fila = $resultado->fetch_assoc()): ?>
            <tr>
                <form action="../modelo/editar.php" method="post">
                    <td><?php echo $fila['id']; ?> <input type="hidden" name="id" value="<?php echo $fila['id']; ?>"> </td>
                    <td><input type="text" name="cedula" value="<?php echo $fila['cedula']; ?>">  </td>
                    <td><input type="text" name="nombre" value="<?php echo $fila['nombre'];?>"  > </td>
                    <td><input type="text" name="apellido" value="<?php echo $fila['apellido']; ?>" > </td>
                    <td>
                        <input type="submit" value="Actualizar"  >
                </form>
                <form action="../modelo/eliminar.php" method="post" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $fila['id']; ?>" > 
                    <input type="submit" value="eliminar"  >

                </form>
                </td>

            </tr>

        <?php endwhile; ?>
    </table>

   </body>
</html>
<?php
echo "<br> <a href= '../destroy.php'> salir </a>";
?>