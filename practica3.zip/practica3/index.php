<?php
session_start();
//include_once 'modelo/conexion.php';
if(isset($_SESSION['rol'])){
    if($_SESSION['rol']=='admin'){
        header('Location: vistas/admin.php');
    }elseif($_SESSION['rol']=='estudiante'){
        header('Location: vistas/estudiante.php');
    }else{
        echo"credenciales incorrectas ";
    }
}
?>
<html>
    <body>
        <form action="modelo/autenticar2.php" method="post">
            Usuario: <input type="text" name="user_name"><br>
            Contraseña: <input type="password" name="pass"><br>
            <input type="submit" value="ingresar">
        </form>
    </body>
</html>